exports.getIdFromSlug = (name) => {
  return name.split('-').pop()
}
