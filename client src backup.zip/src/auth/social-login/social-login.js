import React, { useState, useEffect, useContext } from "react";
import axios from "axios";
import LoginWithFacebook from "./login-with-facebook";
import LoginWithGoogle from "./login-with-google";
import { withRouter } from "react-router-dom";
import { RouteContext } from "../../context/RouteContext";

const options = {
  headers: { "Content-Type": "application/json" }
};

const base = process.env.REACT_APP_FRONTEND_SERVER_URL;

const SocialLogin = ({ setAuthentication, history }) => {
  const [route, setRoute] = useContext(RouteContext);

  const handleSocialData = ({ name, email, id }) => {
    const userData = { name, email, id };
    axios.post(`${base}/api/socialLogin`, userData, options).then(res => {
      setAuthentication(true);
      localStorage.setItem("customer_id", res.data.customer_id);
      route.path ? history.push(route.path) : window.localtion.href("/");
    });
  };

  return (
    <>
      <LoginWithFacebook submittedData={handleSocialData} />
      <LoginWithGoogle submittedData={handleSocialData} />
    </>
  );
};

export default withRouter(SocialLogin);
