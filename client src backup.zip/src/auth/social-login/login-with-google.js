import React, { useState, useEffect, useContext } from "react";
import { useHistory } from "react-router-dom";
import GoogleLogin from "react-google-login";
import { RouteContext } from "../../context/RouteContext";

const LoginWithGoogle = ({ submittedData }) => {

  let history = useHistory();
  const [route, setRoute] = useContext(RouteContext);

  const responseGoogle = response => {
    const { name, email, googleId } = response.profileObj;
    submittedData({ name, email, id: googleId });
    route.path ? history.push(route.path) : window.localtion.href("/");
    // window.location.reload();
    // window.localtion.href("/");
  };

  const onFailure = response => {
    alert("Log in Failed. Try again.");
  };

  const banijjo_com_bd = "347434048473-o9s430qumgukn4fb6c60tdv4ius9sfoh.apps.googleusercontent.com"

  return (
    <GoogleLogin
      clientId={banijjo_com_bd}
      onSuccess={responseGoogle}
      // onFailure={onFailure}
      render={renderProps => (
        <button
          className="loginBtn loginBtn--google"
          onClick={renderProps.onClick}
          disabled={renderProps.disabled}
        >
          Sign in with <b>Google</b>
        </button>
      )}
    />
  );
};

export default LoginWithGoogle;
