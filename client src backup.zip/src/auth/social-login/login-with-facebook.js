import React, { useState, useEffect, useContext } from "react";
import { useHistory } from "react-router-dom";
import FacebookLogin from "react-facebook-login/dist/facebook-login-render-props";
import { RouteContext } from "../../context/RouteContext";

const LoginWithFacebook = ({ submittedData }) => {
  
  let history = useHistory();
  const [route, setRoute] = useContext(RouteContext);

  const responseFacebook = response => {
    submittedData(response);
    route.path ? history.push(route.path) : window.localtion.href("/");
    // window.location.reload();
    // window.localtion.href("/");
  };

  const onFailure = response => {
    alert("Log in Failed. Try again.");
  };

  // const banijjo_com_bd = "1818637888366587";
  const banijjo_com_bd = "2411794199061610"; // app - banijjo.com

  return (
    <FacebookLogin
      appId={banijjo_com_bd}
      fields="name,email,picture"
      callback={responseFacebook}
      // onFailure={onFailure}
      render={renderProps => (
        <button
          onClick={renderProps.onClick}
          className="loginBtn loginBtn--facebook"
        >
          Sign in with <b>Facebook</b>
        </button>
      )}
    />
  );
};

export default LoginWithFacebook;
