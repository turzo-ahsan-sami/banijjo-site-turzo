import React, { useState, useEffect, useContext } from "react";
import { useHistory } from "react-router-dom";
import axios from "axios";
import SocialLogin from "./social-login/social-login";
import { RouteContext } from "../context/RouteContext";

const Login = ({setAuthentication}) => {
  // const [authentication, setAuthentication] = useState(props.setAuthentication);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(false);
  const [route, setRoute] = useContext(RouteContext);

  let history = useHistory();

  const options = {
    headers: { "Content-Type": "application/json" },
  };

  const base = process.env.REACT_APP_FRONTEND_SERVER_URL;

  const onFormSubmit = (e) => {
    e.preventDefault();
    const userData = {
      email: email,
      password: password,
    };

    axios
      .post(`${base}/api/loginCustomerInitial`, userData, options)
      .then((res) => {
        if (res.data.error) {
          setEmail("");
          setPassword("");
          setError(true);
        } else if (res.status == 200) {
          setError(false);
          setAuthentication(true);
          localStorage.setItem("customer_id", res.data.data);
          route.path ? history.push(route.path) : history.push("/");
        }
      })
      .catch((e) => setError(true));
  };

  const handleSocialData = ({ name, email, id }) => {
    const userData = { name, email, id };
    axios.post(`${base}/api/socialLogin`, userData, options).then((res) => {
      setAuthentication(true);
      localStorage.setItem("customer_id", res.data.customer_id);
      route.path ? history.push(route.path) : history.push("/");
    });
  };

  const onChangeHandler = (fieldName, e) => {
    if (fieldName === "email") setEmail(e.target.value);
    if (fieldName === "password") setPassword(e.target.value);
  };

  return (
    <div className="container">
      <div className="row align-items-center">
        <div className="col-md-8 d-none d-lg-block">
          <img
            className="img-fluid mt-4"
            src="https://admin.banijjo.com.bd/upload/product/productImages/banner3.png"
            alt="Ads"
            title="Ads"
          />
        </div>

        <div className="col-md-4">
          <div className="login-form">
            <div className="login-form-div">
              <form onSubmit={onFormSubmit}>
                <h2 className="text-center">Sign in</h2>
                <div className="form-group">
                  <div className="input-group">
                    <span className="input-group-text">
                      <i className="fa fa-user" />
                    </span>
                    <input
                      type="text"
                      className="form-control"
                      name="email"
                      onChange={(e) => onChangeHandler("email", e)}
                      value={email}
                      placeholder="Email"
                    />
                  </div>
                </div>
                <div className="form-group">
                  <div className="input-group">
                    <span className="input-group-text">
                      <i className="fa fa-lock" />
                    </span>
                    <input
                      type="password"
                      className="form-control"
                      name="password"
                      onChange={(e) => onChangeHandler("password", e)}
                      value={password}
                      placeholder="Password"
                    />
                  </div>
                </div>
                <div className="form-group">
                  <button
                    type="submit"
                    className="btn btn-success btn-block login-btn"
                  >
                    Sign in
                  </button>
                </div>
                <div className="clearfix">
                  <a href="#!" className="pull-right text-success disabled">
                    Forgot Password?
                  </a>
                </div>

                {error && (
                  <div className="has-error">
                    <p className="help-block text-center text-danger">
                      Email or Password is not valid! Try Again.
                    </p>
                  </div>
                )}

                <div className="or-seperator">
                  <i>or</i>
                </div>

                {/*Social login*/}
              </form>

              <div className="text-center social-btn">
                <SocialLogin setAuthentication={setAuthentication} history={history} />
              </div>
            </div>
            <div className="hint-text">
              Don't have an account?{" "}
              <a href={`/register`} className="text-success">
                <span>Register Now!</span>
              </a>
            </div>
          </div>
        </div>

        <div className="col-md-8 d-lg-none d-block">
          <img
            className="img-fluid mt-4"
            src="https://admin.banijjo.com.bd/upload/product/productImages/banner3.png"
            alt="Ads"
            title="Ads"
          />
        </div>
      </div>
    </div>
  );
};

export default Login;
