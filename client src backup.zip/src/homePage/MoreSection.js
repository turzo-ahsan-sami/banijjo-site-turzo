import React, { Fragment, useEffect, useRef } from "react";
import PropTypes from "prop-types";
import ProductListingCardMobileView from "../features/ProductListingCardMobileView";
import ProductNameWithDiscount from "../features/ProductNameWithDiscount";
import ProductListingCard from "../features/ProductListingCard";
import "../assets/MoreSection.css";

const { sampleSize } = require("lodash");

class MoreSection extends React.Component {
  state = {
    visible: 0,
    products: [],
    hasMore: true
  };

  loadProducts = () => {
    this.setState(({ products, visible }) => ({
      products: [
        ...products,
        this.props.more.products.slice(visible, visible + 5)
      ]
    }));
  };

  componentDidMount() {
    // this.loadProducts();
  }

  /*loadMore = () => {
    this.setState(prevState => {
      return { visible: prevState.visible + 5 };
    });
  };*/

  fetchMoreData = () => {
    const { visible, products } = this.state;

    if (products.length >= 500) {
      this.setState({ hasMore: false });
      return;
    }
    // a fake async api call like which sends
    // 20 more records in .5 secs
    setTimeout(() => {
      this.setState(prevState => ({
        products: [
          ...prevState.products,
          ...this.props.more.products.slice(
            prevState.visible,
            prevState.visible + 5
          )
        ],
        visible: prevState.visible + 5
      }));
    }, 1500);
  };

  render() {
    const { more } = this.props;
    const { products } = this.state;

    return (
      <Fragment>
        {more !== null && (
          <div className="row">
            <div className="medium-12 columns">
              <h1 className="categoryHeading">{more.title}</h1>
              {/*Mobile View*/}
              {more.products.length > 0 && (
                <div className="row small-up-3 moreCat">
                  {sampleSize(more.products, 9).map(product => (
                    <div
                      className="column"
                      // style={{ paddingRight: "0px", marginBottom: "10px" }}
                      style={{
                        marginBottom: "10px",
                        paddingRight: "10px",
                        paddingLeft: "10px"
                      }}
                      key={product.product_id}
                    >
                      <div className="productCardgrid">
                        <ProductListingCardMobileView product={product} />
                        <ProductNameWithDiscount product={product} />
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/*Desktop View*/}

              <div className="desview">
                <div className="row small-up-5">
                  {products.map(product => (
                    <div
                      className="column"
                      style={{ paddingRight: "0px", marginBottom: "10px" }}
                      key={product.product_id}
                    >
                      <div className="productCardgrid custom-fade-in">
                        <ProductListingCard product={product} />
                        <ProductNameWithDiscount product={product} />
                      </div>
                    </div>
                  ))}
                </div>

                {/*<div>*/}
                {/*  {visible < more.products.length && (*/}
                {/*    <button*/}
                {/*      onClick={this.loadMore}*/}
                {/*      type="button"*/}
                {/*      className="load-more"*/}
                {/*    >*/}
                {/*      Load more*/}
                {/*    </button>*/}
                {/*  )}*/}
                {/*</div>*/}
              </div>
            </div>
          </div>
        )}
      </Fragment>
    );
  }
}

export default MoreSection;
