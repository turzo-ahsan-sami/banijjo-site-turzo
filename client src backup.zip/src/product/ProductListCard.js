import React, { Fragment } from "react";
import PropTypes from "prop-types";
import {
  calDiscountPercentage,
  capitalizeStr,
  shorten_the_name
} from "../utils/utils";

const fileUrl = process.env.REACT_APP_FILE_URL;

const ProductListCard = ({ product }) => {
  return (
    <Fragment>
      <div className="product-image7">
        <a href={`/productDetails/${product.slug}`}>
          <img
            className="pic-1"
            src={`${fileUrl}/upload/product/productImages/${product.home_image}`}
            alt={capitalizeStr(product.product_name)}
            title={capitalizeStr(product.product_name)}
          />
        </a>

        {product.newProduct === 1 && (
          <span className="product-new-label">New</span>
        )}
        {product.discountAmount !== 0 && (
          <span className="product-new-label-discount">
            {calDiscountPercentage(
              product.discountAmount,
              product.productPrice
            )}
            %
          </span>
        )}
      </div>

      <div className="product-content">
        <h1 className="title">
          <a href={`/productDetails/${product.slug}`}>
            {capitalizeStr(shorten_the_name(product.product_name))}
          </a>
        </h1>
        <div className="price">
          ৳&nbsp;{product.productPrice - product.discountAmount}
          {product.discountAmount > 0 && (
            <span>৳&nbsp;{product.productPrice}</span>
          )}
        </div>
      </div>
    </Fragment>
  );
};

ProductListCard.propTypes = {
  product: PropTypes.object.isRequired
};

export default ProductListCard;
