import $ from "jquery";
document.oncontextmenu = function(e) {
  if (e.button === 2) {
    e.preventDefault();
    return false;
  }
};

/*let allImages = document.getElementsByTagName('img');
allImages.forEach(value => {
  value.oncontextmenu = () => {
    return false;
  };
});*/

/*$('img').mousedown(function (e) {
  if(e.button === 2) { // right click
    return false; // do nothing!
  }
}*/

/*$(document).ready(function() {
  $('img').bind('contextmenu', function(e) {
    if (e.button === 2) {
      // right click
      return false; // do nothing!
    }
  });
});*/
